# Klaus
Klaus - a gruvbox hard dark theme for GTK desktops

## Installation
To install, you can clone the repository directly into `~/.themes`

You can also download/install from Pling:

[https://www.pling.com/p/1436515/](https://www.pling.com/p/1436515/)
